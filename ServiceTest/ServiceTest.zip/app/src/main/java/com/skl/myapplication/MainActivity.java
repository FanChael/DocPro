package com.skl.myapplication;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private TestFunciont testFunciont;
    private TestCollection testCollection;
    public TextView timeTv;

    /**
     * 推荐静态+弱引用
     */
    private Handler handler = new MyHandler(this);

    private static class MyHandler extends Handler {
        private WeakReference weakReference;

        MyHandler(MainActivity context) {
            weakReference = new WeakReference(context);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            MainActivity mainActivity = (MainActivity) weakReference.get();
            mainActivity.timeTv.setText("" + msg.obj);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        handler = new MyHandler(this);
        timeTv = findViewById(R.id.timeTv);

        Intent service = new Intent(this, TestLocalService.class);
        testCollection = new TestCollection();
        // bindService(service, testCollection, BIND_AUTO_CREATE);
        // TODO startService启动的方式
        //        startService(service);
        //        startService(service);
        //        startService(service);
        // @hl 启动远程服务
        Intent remoteService = new Intent(this, RemoteService.class);
        startService(remoteService);
    }

    /**
     * 调用者与Service交互的枢纽
     * https://developer.android.google.cn/reference/android/content/ServiceConnection
     */
    private class TestCollection implements ServiceConnection {

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            testFunciont = (TestFunciont) service;
            testFunciont.getService().setResultCallBack(new ResultCallBack() {
                @Override
                public void callBack(Object data) {
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String timeStr = simpleDateFormat.format(new Date(Long.parseLong((String) data)));
                    Log.e("test", "time=" + timeStr);
                    // 界面退出了，消息也发布出去的
                    Message message = Message.obtain();
                    message.obj = timeStr;
                    handler.sendMessage(message);
                }
            });
            Log.e("test", testFunciont.getName());
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            // onServiceDisconnected() 在连接正常关闭的情况下是不会被调用的 - 系统资源不足, 要关闭一些Services
            Log.e("test", "onServiceDisconnected");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //        if (null != testCollection) {
        //            unbindService(testCollection);
        //        }

        // TODO stopService关闭的方式
        // stopService(new Intent(this, TestLocalService.class));
        // @hl 关闭远程服务
        stopService(new Intent(this, RemoteService.class));
    }
}
