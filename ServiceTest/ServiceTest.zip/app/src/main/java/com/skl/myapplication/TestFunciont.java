package com.skl.myapplication;

public interface TestFunciont {
    // 请求网络，实时获取后台状态反馈给前台
    String getName();
    TestLocalService getService();
}
