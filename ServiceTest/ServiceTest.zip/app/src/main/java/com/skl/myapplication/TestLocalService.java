package com.skl.myapplication;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class TestLocalService extends Service {
    // 淘宝获取服务器时间api
    private static final String api = "http://api.m.taobao.com/rest/api3.do?api=mtop.common.getTimestamp";
    private ResultCallBack resultCallBack;
    private boolean status = true;

    @Override
    public IBinder onBind(Intent intent) {
        Log.e("test", "onBind");
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (status) {
                    try {
                        Thread.sleep(1000);

                        URL url = new URL(api);
                        URLConnection urlConnection = url.openConnection();
                        urlConnection.connect();

                        InputStreamReader isr = new InputStreamReader(urlConnection.getInputStream());
                        BufferedReader br = new BufferedReader(isr);
                        String str = "";
                        StringBuilder sb = new StringBuilder();
                        while ((str = br.readLine()) != null) {
                            sb.append(str);
                        }
                        br.close();
                        isr.close();

                        String timeJson = sb.toString() + "";
                        // {"api":"mtop.common.getTimestamp","v":"*",
                        // "ret":["SUCCESS::接口调用成功"],
                        // "data":{"t":"1569228479436"}}
                        // Log.e("test", "timeJson=" + timeJson);
                        JSONObject jsonObject = new JSONObject(timeJson);
                        jsonObject = jsonObject.getJSONObject("data");
                        String time = jsonObject.getString("t");
                        // Log.e("test", "time=" + time);
                        // status做容错性判断
                        if (status && null != resultCallBack) {
                            resultCallBack.callBack(time);
                        }
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
        return new TestBinder();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //return super.onStartCommand(intent, flags, startId);
        Log.e("test", "onStartCommand");
        // TODO handleCommand(intent); // 比如处理播放，暂停，上一首，下一首等命令; 多次startService(intentCommond),多次该回调
        return START_STICKY;
        // 如果service进程被kill掉，保留service的状态为开始状态，但不保留递送的intent对象。
        // 随后系统会尝试重新创建service，由于服务状态为开始状态，所以创建服务后一定会调用onStartCommand(Intent,int,int)方法。
        // 如果在此期间没有任何启动命令被传递到service，那么参数Intent将为null
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.e("test", "onUnbind");
        status = false;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("test", "onDestroy");
    }

    /**
     * @hl 回调作为Service主动通知调用者而设置
     * @param resultCallBack
     */
    public void setResultCallBack(ResultCallBack resultCallBack) {
        this.resultCallBack = resultCallBack;
    }

    /**
     * @hl 调用者主动获取Service提供的数据
     * 该Binder对象作为Service给调用者的数据信息媒介 - 后续有必要了解Binder通信机制
     * https://developer.android.google.cn/reference/kotlin/android/os/Binder?hl=en
     */
    public class TestBinder extends Binder implements TestFunciont {

        @Override
        public String getName() {
            // 请求网络，实时获取后台状态反馈给前台
            return "sb is you?";
        }

        /**
         * 获取当前Service的实例
         *
         * @return
         */
        @Override
        public TestLocalService getService() {
            return TestLocalService.this;
        }
    }
}
