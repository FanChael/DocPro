package com.skl.myapplication;

public interface ResultCallBack {
    public void callBack(Object data);
}
