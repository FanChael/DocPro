package com.skl.testremoteservice;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.skl.myapplication.IMyAidlInterface;

public class MainActivity extends AppCompatActivity {

    private IMyAidlInterface iMyAidlInterface;
    public static final String NAME_REMOTE_SERVICE = "com.skl.myapplication.RemoteService" ;
    public static final String PACKAGE_REMOTE_SERVICE = "com.skl.myapplication" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent();
        // 隐式启动，可以不用设置Action
        // intent.setAction("com.hl.loginservice");
        // android 5.0以后直设置action不能启动相应的服务，需要设置packageName或者Component
        intent.setPackage("com.skl.myapplication");
        // 显示调用需要ComponentName方式
        //        ComponentName componentName = new ComponentName(PACKAGE_REMOTE_SERVICE ,NAME_REMOTE_SERVICE);
        //        intent.setComponent (componentName );
        bindService(intent, serviceConnection, BIND_AUTO_CREATE);
    }

    /**
     * 调用者与Service交互的枢纽
     * https://developer.android.google.cn/reference/android/content/ServiceConnection
     */
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // 获取Binder的接口(代理实例对象)
            // return new com.skl.testremoteservice.IMyAidlInterface.Stub.Proxy(obj);
            iMyAidlInterface = IMyAidlInterface.Stub.asInterface(service);
            try {
                // 获取服务时间
                Log.e("test", iMyAidlInterface.getTime());
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != serviceConnection) {
            unbindService(serviceConnection);
        }
    }
}
