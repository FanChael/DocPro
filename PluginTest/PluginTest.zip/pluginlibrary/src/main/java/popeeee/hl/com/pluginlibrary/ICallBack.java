package popeeee.hl.com.pluginlibrary;

public interface ICallBack {
    void callback(PluginProvider pluginProvider);
}
