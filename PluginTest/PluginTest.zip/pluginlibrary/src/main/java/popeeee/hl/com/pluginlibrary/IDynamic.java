package popeeee.hl.com.pluginlibrary;

public interface IDynamic {
    void invokeCallBack(ICallBack callBack);
}
