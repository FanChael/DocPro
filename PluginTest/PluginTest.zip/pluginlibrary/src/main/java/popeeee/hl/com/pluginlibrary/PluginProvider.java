package popeeee.hl.com.pluginlibrary;

public interface PluginProvider {
    String getFeature();

    void setFeature(String feature);
}
