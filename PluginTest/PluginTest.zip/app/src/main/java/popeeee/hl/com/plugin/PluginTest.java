package popeeee.hl.com.plugin;

import popeeee.hl.com.pluginlibrary.PluginProvider;

public class PluginTest implements PluginProvider{
    private String feature = "不帅";

    @Override
    public String getFeature() {
        return feature;
    }

    @Override
    public void setFeature(String feature) {
        this.feature = feature;
    }
}
