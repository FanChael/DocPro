package popeeee.hl.com.plugin;

import android.content.Context;
import android.os.Environment;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.io.File;

import dalvik.system.DexClassLoader;
import popeeee.hl.com.plugin.utils.FileUtil;
import popeeee.hl.com.plugin.utils.SystemUtils;
import popeeee.hl.com.pluginlibrary.ICallBack;
import popeeee.hl.com.pluginlibrary.IDynamic;
import popeeee.hl.com.pluginlibrary.PluginProvider;

public class MainActivity extends AppCompatActivity {
    private String pluginApkName = "plugin-debug.apk";  ///< 插件apk名称
    private String apkPath;         ///< apk存储路径
    private String apkDexPath;      ///< apk解压dex的目录、和apk存放路径为一个路径
    private DexClassLoader dexClassLoader;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(newBase);

        ///< 获取apk准备存储的应用本地缓存路径
        this.apkDexPath = SystemUtils.getCacheDirectory(this, Environment.DIRECTORY_DOWNLOADS).getPath();
        ///< 拷贝assets下的plugin-debug.apk到apkPath目录并获取实际路径
        this.apkPath = FileUtil.copyFilesFromAssets(this, pluginApkName, apkDexPath);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ///< 判断apk是否存在
        File file = new File(apkPath);
        if (!file.exists()) {
            Toast.makeText(this, "文件不存在", Toast.LENGTH_SHORT).show();
            return;
        }
        ///< 加载apk并获取DexClassLoader对象，如果有.so需要考虑第三个参数
        this.dexClassLoader = new DexClassLoader(apkPath, apkDexPath, null, this.getClassLoader());
    }

    /**
     * 默认hello world文本框添加点击事件 android:onClick="CallPlugin"
     *
     * @param view
     */
    public void CallPlugin(View view) {
        try {
            ///< 加载插件的类(插件的包名.类名)
            Class<?> mClass = dexClassLoader.loadClass("popeeee.hl.com.plugin.Dynamic");

            /// 1. 反射方式调用
//            ///< 获取类的实例
//            Object beanObject = mClass.newInstance();
//
//            ///< 然后通过反射获取对应的方法
//            Method setFeatureMethod = mClass.getMethod("setFeature", String.class);
//            setFeatureMethod.setAccessible(true);
//            Method getFeatureMethod = mClass.getMethod("getFeature");
//            getFeatureMethod.setAccessible(true);
//
//            ///< 然后执行对应方法进行相关设置和获取
//            setFeatureMethod.invoke(beanObject, "丑的不行呀！");
//            String feature = (String) getFeatureMethod.invoke(beanObject);

//            ///< 然后本地进行一些提示等操作
//            Toast.makeText(this, feature, Toast.LENGTH_SHORT).show();

//            /// 2. 强制转换对应包含操作方法的对象
//            PluginTest pluginTest = (PluginTest) mClass.newInstance();
//            pluginTest.setFeature("丑的还可以呀2！");
//
//            ///< 然后本地进行一些提示等操作
//            Toast.makeText(this, pluginTest.getFeature(), Toast.LENGTH_SHORT).show();

//            ///< 面向接口编程调用插件代码
//            PluginProvider pluginProvider = (PluginProvider) mClass.newInstance();
//            pluginProvider.setFeature("不帅么?");
//
//            ///< 然后本地进行一些提示等操作
//            Toast.makeText(this, pluginProvider.getFeature(), Toast.LENGTH_SHORT).show();

            ///< 面向切面编程调用插件代码
            IDynamic iDynamic = (IDynamic) mClass.newInstance();
            iDynamic.invokeCallBack(new ICallBack() {
                @Override
                public void callback(PluginProvider pluginProvider) {
                    Looper.prepare();
                    ///< 然后本地进行一些提示等操作
                    Toast.makeText(MainActivity.this, pluginProvider.getFeature(), Toast.LENGTH_SHORT).show();
                    Looper.loop();
                }
            });
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }
    }
}
