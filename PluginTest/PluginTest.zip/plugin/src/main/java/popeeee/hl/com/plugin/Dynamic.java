package popeeee.hl.com.plugin;

import popeeee.hl.com.pluginlibrary.ICallBack;
import popeeee.hl.com.pluginlibrary.IDynamic;

public class Dynamic implements IDynamic {
    @Override
    public void invokeCallBack(final ICallBack callBack) {
                    ///< 操作获取某些信息，然后回调给宿主
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(3);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                PluginTest pluginTest = new PluginTest();
                pluginTest.setFeature("我来自互联网，我标志了人类的一大进步！“呸，不要脸!");
                callBack.callback(pluginTest);
            }
        }).start();
    }
}
