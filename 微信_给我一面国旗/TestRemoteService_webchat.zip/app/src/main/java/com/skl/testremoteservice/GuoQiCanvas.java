package com.skl.testremoteservice;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

/**
 * @HL - https://www.zhihu.com/people/monkey.d.luffy/activities
 * 简单图片拼接Play一下，@微信官方 给我一面国旗
 */
public class GuoQiCanvas extends View {
    private Context context;///< 上下文
    private Bitmap mBitmap, bitmapGuoQi;

    private Canvas cacheCanvas;
    private Bitmap cacheBitmap;
    private int screenWidth, screenHeight;

    private Rect src, dst;
    private Rect srcGuoqi, dstGuoqi, dstComposeSrc, dstComposeGuoqi;

    public GuoQiCanvas(Context context) {
        this(context, null);
    }

    public GuoQiCanvas(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public GuoQiCanvas(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public GuoQiCanvas(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        this.context = context;
        WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        screenWidth = wm.getDefaultDisplay().getWidth();
        screenHeight = wm.getDefaultDisplay().getHeight();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        //        if (null != mBitmap) {
        //            int originShowH = (mBitmap.getWidth() > screenWidth / 2 ? screenWidth / 2 : mBitmap.getWidth()) * mBitmap.getHeight() / mBitmap.getWidth();
        //            setMeasuredDimension(screenWidth, originShowH * 2);
        //        }
        // 直接全屏
        setMeasuredDimension(screenWidth, screenHeight);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // 合成图片 - 此时不绘制单个图片
        if (null != cacheBitmap) {
            cacheCanvas.drawBitmap(mBitmap, src, src, null);
            cacheCanvas.drawBitmap(bitmapGuoQi, srcGuoqi, dstComposeGuoqi, null);
            canvas.drawBitmap(cacheBitmap, src, dstComposeSrc, null);

            // 导出到相册
            exportToCamera();

            if (null != mBitmap) {
                mBitmap.recycle();
                mBitmap = null;
            }
            if (null != bitmapGuoQi) {
                bitmapGuoQi.recycle();
                bitmapGuoQi = null;
            }
        } else {
            // 绘制原始图片
            if (null != mBitmap) {
                canvas.drawBitmap(mBitmap, src, dst, null);
            }

            // 绘制拼接图片
            if (null != bitmapGuoQi) {
                canvas.drawBitmap(bitmapGuoQi, srcGuoqi, dstGuoqi, null);
            }
        }
    }

    /**
     * 绘制原始图片
     *
     * @param bitmap
     */
    public void drawSrcBitmap(Bitmap bitmap) {
        if (null != cacheBitmap) {
            cacheBitmap.recycle();
            cacheBitmap = null;
        }

        this.mBitmap = bitmap;

        src = new Rect(0, 0,
                mBitmap.getWidth(),
                mBitmap.getHeight());
        // 指定图片绘制区域(左上角的四分之一)
        int originShowW = (mBitmap.getWidth() > screenWidth / 2 ? screenWidth / 2 : mBitmap.getWidth());
        int originShowH = originShowW * mBitmap.getHeight() / mBitmap.getWidth();
        dst = new Rect(0, 0,
                originShowW,
                originShowH);

        // 根据图片信息更新控件大小 - 还是保持全屏吧
        // requestLayout();
        // 请求刷新渲染
        invalidate();
    }

    /**
     * 绘制拼接的目标图片
     *
     * @param bitmap
     */
    public void drawDstBitmap(Bitmap bitmap) {
        if (null != cacheBitmap) {
            cacheBitmap.recycle();
            cacheBitmap = null;
        }

        this.bitmapGuoQi = bitmap;

        srcGuoqi = new Rect(0, 0,
                bitmapGuoQi.getWidth(),
                bitmapGuoQi.getHeight());
        // 指定图片绘制区域(右上角的四分之一)
        int originShowW = (bitmapGuoQi.getWidth() > screenWidth / 2 ? screenWidth / 2 : bitmapGuoQi.getWidth());
        int originShowH = originShowW * bitmapGuoQi.getHeight() / bitmapGuoQi.getWidth();
        dstGuoqi = new Rect(
                screenWidth / 2,
                0,
                originShowW + screenWidth / 2,
                originShowH);

        invalidate();
    }

    /**
     * 图像合成
     */
    public boolean compose() {
        // 有了就导出到相册
        if (null != cacheBitmap){
            exportToCamera();
            return true;
        }

        if (null == mBitmap) {
            return false;
        }

        if (null == bitmapGuoQi) {
            return false;
        }

        this.cacheBitmap = Bitmap.createBitmap(mBitmap.getWidth(), mBitmap.getHeight(), Bitmap.Config.ARGB_8888);
        this.cacheCanvas = new Canvas(cacheBitmap);

        // 国旗图片位置
        int guoqiShowW = mBitmap.getWidth() * 3 / 4;
        int guoqiShowH = mBitmap.getWidth() * 1 / 4 * bitmapGuoQi.getHeight() / bitmapGuoQi.getWidth();
        this.dstComposeGuoqi = new Rect(
                guoqiShowW,
                mBitmap.getHeight() - guoqiShowH,
                mBitmap.getWidth(),
                mBitmap.getHeight());

        // 合成图片cacheBitmap绘制的位置
        this.dstComposeSrc = new Rect(
                dst.width() / 2,
                0,
                dst.width() / 2 + dst.width(),
                dst.height());

        invalidate();
        return true;
    }

    /**
     * 导出到相册
     */
    public void exportToCamera() {
        if (null != cacheBitmap) {
            File sdRoot = context.getCacheDir();
            String save_path = sdRoot + "/temp.png";

            File file = new File(save_path);
            if (file.exists()) {
                file.delete();
            }
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                cacheBitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                fileOutputStream.close();

                // 插入到相册
                saveBmp2Gallery(cacheBitmap, save_path);
                Toast.makeText(context, "已经保存到相册", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e("GuoQi Error--------->", e.toString());
            }
        }
    }

    /**
     * @param bmp 获取的bitmap数据
     * @param pic 图片路径
     */
    public void saveBmp2Gallery(Bitmap bmp, String pic) {
        // 声明文件对象
        File file = new File(pic);

        // 插入相册
        MediaStore.Images.Media.insertImage(context.getContentResolver(),
                bmp, "GuoQi", null);
        // 通知相册更新
        Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        Uri uri = Uri.fromFile(file);
        intent.setData(uri);
        context.sendBroadcast(intent);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Log.e("GuoQi", "onDetachedFromWindow");
        if (null != cacheBitmap) {
            cacheBitmap.recycle();
            cacheBitmap = null;
        }
    }
}
