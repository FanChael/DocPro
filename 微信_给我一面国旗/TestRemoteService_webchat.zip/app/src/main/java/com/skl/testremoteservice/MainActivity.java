package com.skl.testremoteservice;

import android.Manifest;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.RemoteException;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Toast;

import com.skl.myapplication.IMyAidlInterface;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private IMyAidlInterface iMyAidlInterface;
    public static final String NAME_REMOTE_SERVICE = "com.skl.myapplication.RemoteService";
    public static final String PACKAGE_REMOTE_SERVICE = "com.skl.myapplication";

    private WebView tetsss;
    private GuoQiCanvas guoQiCanvas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent();
        // 隐式启动，可以不用设置Action
        // intent.setAction("com.hl.loginservice");
        // android 5.0以后直设置action不能启动相应的服务，需要设置packageName或者Component
        intent.setPackage("com.skl.myapplication");
        // 显示调用需要ComponentName方式
        //        ComponentName componentName = new ComponentName(PACKAGE_REMOTE_SERVICE ,NAME_REMOTE_SERVICE);
        //        intent.setComponent (componentName );
        // bindService(intent, serviceConnection, BIND_AUTO_CREATE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                //没有权限则申请权限
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
            } else {
            }
        } else {
            //小于6.0，不用申请权限，直接执行
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                //没有权限则申请权限
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            } else {
            }
        } else {
            //小于6.0，不用申请权限，直接执行
        }

//        tetsss = findViewById(R.id.tetsss);
//        tetsss.loadUrl("https://www.lieyunwang.com/ntopic/summit2019#summit2019-0");
        guoQiCanvas = findViewById(R.id.aiguoCanvas);
    }

    /**
     * 调用者与Service交互的枢纽
     * https://developer.android.google.cn/reference/android/content/ServiceConnection
     */
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // 获取Binder的接口(代理实例对象)
            // return new com.skl.testremoteservice.IMyAidlInterface.Stub.Proxy(obj);
            iMyAidlInterface = IMyAidlInterface.Stub.asInterface(service);
            try {
                // 获取服务时间
                Log.e("test", iMyAidlInterface.getTime());
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        if (null != serviceConnection) {
//            unbindService(serviceConnection);
//        }
    }

    /**
     * 选择合成点击事件
     *
     * @param view
     */
    public void PicOpt(View view) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // 未授权，申请授权(从相册选择图片需要读取存储卡的权限)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 110);
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    // 没有权限则申请权限
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                } else {
                    // 已授权，获取照片
                    switch (view.getId()) {
                        case R.id.originBtn:
                            choosePhoto(0);
                            break;
                        case R.id.targetBtn:
                            choosePhoto(1);
                            break;
                        case R.id.composeBtn:
                            guoQiCanvas.compose();
                            break;
                    }
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // 获取图片成功进行绘制
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case 0:
                case 1:
                    Uri uri = data.getData();
                    try {
                        Bitmap mBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                        if (0 == requestCode) {
                            guoQiCanvas.drawSrcBitmap(mBitmap);
                        } else if (1 == requestCode) {
                            guoQiCanvas.drawDstBitmap(mBitmap);
                        }
                    } catch (IOException e) {
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        }
    }

    /**
     * 选择相册图片
     *
     * @param type
     */
    private void choosePhoto(int type) {
        Intent intentToPickPic = new Intent(Intent.ACTION_PICK, null);
        intentToPickPic.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
        startActivityForResult(intentToPickPic, type);
    }
}
